// ============================================================
//  LG SOFT — script.js
// ============================================================

function togglePassword() {
  var input   = document.getElementById('password');
  var icon    = document.getElementById('eyeIcon');
  var visible = input.type === 'text';
  input.type  = visible ? 'password' : 'text';
  icon.innerHTML = visible
    ? '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>'
    : '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>';
}

function _lgShowToast(msg, type) {
  var old = document.getElementById('_lgToast');
  if (old) old.remove();
  var colors = { success:{ border:'#16a34a',bg:'#dcfce7',text:'#16a34a' }, error:{ border:'#e53935',bg:'#fde8e8',text:'#e53935' }, info:{ border:'#1d6fb5',bg:'#dbeafe',text:'#1d6fb5' } };
  var c = colors[type] || colors.info;
  var icons = { success:'<polyline points="20 6 9 17 4 12"/>', error:'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>', info:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' };
  var t = document.createElement('div');
  t.id = '_lgToast';
  t.style.cssText = 'position:fixed;top:24px;right:24px;z-index:99999;background:#fff;border-radius:14px;padding:16px 20px;min-width:300px;max-width:380px;box-shadow:0 8px 32px rgba(0,0,0,0.13);border-left:4px solid '+c.border+';display:flex;align-items:center;gap:14px;font-family:Segoe UI,Arial,sans-serif';
  t.innerHTML = '<div style="width:36px;height:36px;border-radius:50%;background:'+c.bg+';display:flex;align-items:center;justify-content:center;flex-shrink:0"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="'+c.text+'" stroke-width="2.5">'+(icons[type]||icons.info)+'</svg></div><span style="font-size:14px;font-weight:600;color:#111;flex:1">'+msg+'</span><button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:#bbb;font-size:18px;padding:0">×</button>';
  document.body.appendChild(t);
  setTimeout(function(){ if(t.parentElement){ t.style.transition='opacity 0.3s'; t.style.opacity='0'; setTimeout(function(){ if(t.parentElement)t.remove(); },300); } },3000);
}

document.addEventListener('DOMContentLoaded', function () {
  var loginForm  = document.getElementById('loginForm');
  var signupForm = document.getElementById('signupForm');

  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = document.getElementById('email').value.trim();
      var password = document.getElementById('password').value.trim();
      var valid = true;
      document.getElementById('emailError').textContent    = '';
      document.getElementById('passwordError').textContent = '';
      if (!email)    { document.getElementById('emailError').textContent    = 'Enter email address'; valid = false; }
      if (!password) { document.getElementById('passwordError').textContent = 'Enter password';      valid = false; }
      if (!valid) return;
      var validUser = 'admin@gmail.com';
      var validPass = '123456';
      if (email === validUser && password === validPass) {
        localStorage.setItem('loggedIn', 'true');
        _lgShowToast('Login Successful ✅', 'success');
        setTimeout(function () { window.location.href = 'welcome.html'; }, 1000);
      } else {
        document.getElementById('passwordError').textContent = 'Invalid username or password';
        _lgShowToast('Login Failed ❌', 'error');
      }
    });
  }

  if (signupForm) {
    signupForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var firstName = document.getElementById('firstName').value.trim();
      var lastName  = document.getElementById('lastName').value.trim();
      var email     = document.getElementById('email').value.trim();
      var phone     = document.getElementById('phone').value.trim();
      var password  = document.getElementById('password').value.trim();
      var valid = true;
      ['firstName','lastName','email','phone','password'].forEach(function(f){ var el=document.getElementById(f+'Error'); if(el)el.textContent=''; });
      if (!firstName) { document.getElementById('firstNameError').textContent='Enter first name'; valid=false; }
      if (!lastName)  { document.getElementById('lastNameError').textContent='Enter last name';   valid=false; }
      if (!email)     { document.getElementById('emailError').textContent='Enter email';          valid=false; }
      if (!phone)     { document.getElementById('phoneError').textContent='Enter phone';          valid=false; }
      if (!password || password.length < 6) { document.getElementById('passwordError').textContent='Min. 6 characters'; valid=false; }
      if (!valid) return;
      localStorage.setItem('user', JSON.stringify({ firstName:firstName, lastName:lastName, email:email, phone:phone }));
      localStorage.setItem('loggedIn', 'true');
      _lgShowToast('Account created! Redirecting…', 'success');
      setTimeout(function () { window.location.href = 'welcome.html'; }, 1200);
    });
  }
});
