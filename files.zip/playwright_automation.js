// ============================================================
//  LG SOFT — Playwright Automation
//  Called by dashboard.html via: runPlaywrightAutomation(defect)
//
//  ✏️  UPDATE THE CONFIG SECTION BELOW BEFORE RUNNING
//  Run: node playwright_automation.js
// ============================================================

const { chromium } = require('playwright');

// ══════════════════════════════════════════════════════════════
//  ✏️  CONFIG — Update these values
// ══════════════════════════════════════════════════════════════
const CONFIG = {

  // --- LG App ---
  appUrl:      'http://localhost:5500/index.html',  // ← Your app URL
  appEmail:    'admin@gmail.com',                   // ← Login email
  appPassword: '123456',                            // ← Login password

  // --- External Tracker ---
  externalUrl:      'https://YOUR_TRACKER_URL',     // ← External tracker URL
  externalUsername: 'YOUR_USERNAME',                // ← External username
  externalPassword: 'YOUR_PASSWORD',                // ← External password

  // --- External Tracker Selectors (update to match external site) ---
  sel: {
    extUsername:  '#username',          // ← username input selector
    extPassword:  '#password',          // ← password input selector
    extLoginBtn:  '#login-btn',         // ← login button selector
    extSearchBox: '#search',            // ← search box selector
    extPlusBtn:   'button.create-new',  // ← + / Create New button selector
    extSubmitBtn: '#submit-btn',        // ← final submit button selector

    // External form field selectors — map to your external tracker's form
    extTitle:       '#summary',         // ← title/summary field
    extDescription: '#description',     // ← description field
    extPriority:    '#priority',        // ← priority dropdown
    extAssignee:    '#assignee',        // ← assignee field
    extStatus:      '#status',          // ← status dropdown
  },

  // --- Defect data (passed in from dashboard, override here for standalone run) ---
  defect: {
    title:       'YOUR_DEFECT_TITLE',
    status:      'Open',
    priority:    'Critical',
    assignedTo:  'YOUR_ASSIGNEE',
    date:        '2025-04-15',
    tracker:     '',
    parent:      '',
    testCaseId:  '',
    description: 'YOUR_DESCRIPTION',
  }
};

// ══════════════════════════════════════════════════════════════
//  AUTOMATION — runs the full flow
// ══════════════════════════════════════════════════════════════
async function runAutomation(defect) {
  defect = defect || CONFIG.defect;
  const browser = await chromium.launch({ headless: false, slowMo: 400 });
  const context = await browser.newContext();
  const page    = await context.newPage();

  async function fill(sel, val, isSelect) {
    if (!val) return;
    try {
      await page.waitForSelector(sel, { timeout: 3000 });
      isSelect ? await page.selectOption(sel, val) : await page.fill(sel, val);
    } catch(e) { console.warn('  ⚠  Skip field:', sel); }
  }

  async function extFill(p, sel, val, isSelect) {
    if (!val || !sel) return;
    try {
      await p.waitForSelector(sel, { timeout: 3000 });
      const tag = await p.locator(sel).evaluate(el => el.tagName.toLowerCase());
      tag === 'select' ? await p.selectOption(sel, val) : await p.fill(sel, val);
    } catch(e) { console.warn('  ⚠  Skip external field:', sel); }
  }

  try {

    // ── STEP 1: Login to LG App ──────────────────────────────
    console.log('\n🔐  Logging in to LG Soft…');
    await page.goto(CONFIG.appUrl, { waitUntil: 'domcontentloaded' });
    await page.fill('#email',    CONFIG.appEmail);
    await page.fill('#password', CONFIG.appPassword);
    await page.click('button[type="submit"]');
    await page.waitForURL('**/welcome.html', { timeout: 8000 });
    console.log('  ✅  Logged in');

    // ── STEP 2: Go to Dashboard ──────────────────────────────
    console.log('\n🚀  Opening Dashboard…');
    await page.click('a.btn-get-started');
    await page.waitForURL('**/dashboard.html', { timeout: 8000 });
    console.log('  ✅  Dashboard loaded');

    // ── STEP 3: Open Create Defect ───────────────────────────
    console.log('\n📝  Opening Create Defect…');
    await page.click('.nav-item:has-text("Create")');
    await page.waitForSelector('#page-create.active', { timeout: 5000 });
    console.log('  ✅  Create Defect page open');

    // ── STEP 4: Fill Required Fields ────────────────────────
    console.log('\n✍️   Filling defect form…');
    await fill('#defTitle',    defect.title);
    await fill('#defStatus',   defect.status,   true);
    await fill('#defPriority', defect.priority, true);
    await fill('#defAssigned', defect.assignedTo);
    await fill('#defDate',     defect.date);

    // ── STEP 5: Fill Optional Fields ────────────────────────
    await fill('#defTracker',             defect.tracker);
    await fill('#defParent',              defect.parent);
    await fill('#defTcid',                defect.testCaseId);
    await fill('#defFunction',            defect.func || '');
    await fill('#defBugSymptom',          defect.bugSymptom || '');
    await fill('#defSubmittedBy',         defect.submittedBy || '');
    await fill('#defModifiedBy',          defect.modifiedBy || '');
    await fill('#defWatcher',             defect.watcher || '');
    await fill('#defAffectedVersion',     defect.affectedVersion || '');
    await fill('#defTestEnvironment',     defect.testEnvironment || '');
    await fill('#defHwVersion',           defect.hwVersion || '');
    await fill('#defResolution',          defect.resolution || '');
    await fill('#defReproducibility',     defect.reproducibility || '');
    await fill('#defOccurrenceRate',      defect.occurrenceRate || '');
    await fill('#defSeverity',            defect.severity || '');
    await fill('#defRootCauseType',       defect.rootCauseType || '');
    await fill('#defTestLocation',        defect.testLocation || '');
    await fill('#defNpi',                 defect.npi || '');
    await fill('#defNpiEventOrder',       defect.npiEventOrder || '');
    await fill('#defRootCause',           defect.rootCause || '');
    await fill('#defCountermeasure',      defect.countermeasure || '');
    await fill('#defCommitId',            defect.commitId || '');
    await fill('#defFixedVersion',        defect.fixedVersion || '');
    await fill('#defVariant',             defect.variant || '');
    await fill('#defVariantVehicleInfo',  defect.variantVehicleInfo || '');
    await fill('#defConfirmationVersion', defect.confirmationVersion || '');
    await fill('#defHoldingReason',       defect.holdingReason || '');
    await fill('#defTestField',           defect.testField || '');
    await fill('#defBugOwner',            defect.bugOwner || '');
    await fill('#defOpenToOem',           defect.openToOem || '');
    await fill('#defAgainstWho',          defect.againstWho || '');
    await fill('#defDocumentIssue',       defect.documentIssue || '');
    await fill('#defReqBased',            defect.reqBased || '');
    await fill('#defTestStrategy',        defect.testStrategy || '');
    await fill('#defVlmKey',              defect.vlmKey || '');
    await fill('#defVlmStatus',           defect.vlmStatus || '');
    await fill('#defVlmAssignee',         defect.vlmAssignee || '');
    await fill('#defVlmReporter',         defect.vlmReporter || '');
    await fill('#defOemKey',              defect.oemKey || '');
    await fill('#defOemStatus',           defect.oemStatus || '');
    await fill('#defOemAssignee',         defect.oemAssignee || '');
    await fill('#defOemReporter',         defect.oemReporter || '');
    await fill('#defLastSendTime',        defect.lastSendTime || '');
    await fill('#defLastSendLog',         defect.lastSendLog || '');
    await fill('#defReopenCount',         defect.reopenCount || '');
    await fill('#defLabels',              defect.labels || '');

    // Description (rich text)
    if (defect.description) {
      await page.locator('#rteEditor').click();
      await page.locator('#rteEditor').evaluate((el, text) => {
        el.innerHTML = '';
        const p = document.createElement('p');
        p.textContent = text;
        el.appendChild(p);
      }, defect.description);
    }
    console.log('  ✅  All fields filled');

    // ── STEP 6: Submit Defect ────────────────────────────────
    console.log('\n📤  Submitting defect…');
    await page.click('.submit-btn');
    await page.waitForSelector('.toast-item', { timeout: 5000 });
    console.log('  ✅  Defect submitted — toast shown');
    await page.waitForTimeout(1500);

    // ── STEP 7: Open External Tracker ───────────────────────
    console.log('\n🌐  Opening external tracker…');
    const ext = await context.newPage();
    await ext.goto(CONFIG.externalUrl, { waitUntil: 'domcontentloaded' });

    // ── STEP 8: Login to External ───────────────────────────
    console.log('\n🔐  Logging in to external tracker…');
    await extFill(ext, CONFIG.sel.extUsername, CONFIG.externalUsername);
    await extFill(ext, CONFIG.sel.extPassword, CONFIG.externalPassword);
    await ext.click(CONFIG.sel.extLoginBtn);
    await ext.waitForLoadState('networkidle', { timeout: 10000 });
    console.log('  ✅  Logged in to external tracker');

    // ── STEP 9: Search ───────────────────────────────────────
    console.log('\n🔍  Searching in external tracker…');
    await ext.waitForSelector(CONFIG.sel.extSearchBox, { timeout: 8000 });
    await ext.fill(CONFIG.sel.extSearchBox, defect.title);
    await ext.keyboard.press('Enter');
    await ext.waitForLoadState('networkidle', { timeout: 8000 });
    console.log('  ✅  Search done');

    // ── STEP 10: Click + button ──────────────────────────────
    console.log('\n➕  Clicking + (Create New)…');
    await ext.waitForSelector(CONFIG.sel.extPlusBtn, { timeout: 8000 });
    await ext.click(CONFIG.sel.extPlusBtn);
    await ext.waitForLoadState('networkidle', { timeout: 8000 });
    console.log('  ✅  Create form opened');

    // ── STEP 11: Fill External Form ─────────────────────────
    console.log('\n✍️   Filling external tracker form…');
    await extFill(ext, CONFIG.sel.extTitle,       defect.title);
    await extFill(ext, CONFIG.sel.extDescription, defect.description);
    await extFill(ext, CONFIG.sel.extPriority,    defect.priority, true);
    await extFill(ext, CONFIG.sel.extAssignee,    defect.assignedTo);
    await extFill(ext, CONFIG.sel.extStatus,      defect.status,   true);
    console.log('  ✅  External form filled');

    // ── STEP 12: Submit on External ─────────────────────────
    console.log('\n📤  Submitting on external tracker…');
    await ext.click(CONFIG.sel.extSubmitBtn);
    await ext.waitForLoadState('networkidle', { timeout: 10000 });
    console.log('  ✅  Submitted on external tracker!');

    // ── STEP 13: Show Success Popup on LG App ───────────────
    console.log('\n🎉  Showing success popup on LG app…');
    await page.bringToFront();
    await page.evaluate(function(title) {
      var existing = document.getElementById('_pwSuccessOverlay');
      if (existing) existing.remove();
      var overlay = document.createElement('div');
      overlay.id = '_pwSuccessOverlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;z-index:99999';
      overlay.innerHTML =
        '<div style="background:#fff;border-radius:20px;padding:44px 52px;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,0.3);max-width:420px;width:90%">' +
          '<div style="width:76px;height:76px;background:#dcfce7;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 22px">' +
            '<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>' +
          '</div>' +
          '<h2 style="font-size:24px;font-weight:800;color:#111;margin-bottom:10px;font-family:DM Sans,Segoe UI,sans-serif">Defect Created!</h2>' +
          '<p style="font-size:14px;color:#555;line-height:1.6;margin-bottom:6px;font-family:DM Sans,Segoe UI,sans-serif"><strong style="color:#111">' + title + '</strong></p>' +
          '<p style="font-size:13px;color:#888;margin-bottom:30px;font-family:DM Sans,Segoe UI,sans-serif">Saved in LG Tracker &amp; submitted to external tracker successfully.</p>' +
          '<button onclick="document.getElementById(\'_pwSuccessOverlay\').remove()" style="background:linear-gradient(135deg,#a50034,#6b0022);color:#fff;border:none;border-radius:10px;padding:13px 36px;font-size:15px;font-weight:700;cursor:pointer;font-family:DM Sans,Segoe UI,sans-serif">Done</button>' +
        '</div>';
      document.body.appendChild(overlay);
    }, defect.title);

    console.log('\n✅✅✅  AUTOMATION COMPLETE!\n');

  } catch (err) {
    console.error('\n❌  Error:', err.message);
    console.error('   Check your CONFIG selectors and URLs.\n');
  }
  // Uncomment to auto-close browser:
  // await browser.close();
}

runAutomation();
